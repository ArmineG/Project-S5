from django.urls import path
from .views import home, user_main, search

urlpatterns = [
        path("", home, name='home'),
        path("user/", user_main, name='user'),
        path("search/", search, name='search')
]