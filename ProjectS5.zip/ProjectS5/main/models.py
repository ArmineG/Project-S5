from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models.signals import pre_save
from django.dispatch import receiver


# Create your models here.
def validate_mail(value):
    """
    If the email is from ufar.am, return the email, else raise a validation error

    :param value: The value that is being validated
    :return: The value is being returned if the email is from ufar.am.
    """
    if "@ufar.am" in value:
        return value
    else:
        # Raising an error if the email is not from ufar.am
        raise ValidationError("This field accepts mail of ufar only")


class Employee(models.Model):
    name = models.CharField(max_length=100, verbose_name='Name')
    surname = models.CharField(max_length=100, verbose_name='Surname')
    email = models.EmailField(max_length=100, verbose_name='Email', validators=(validate_mail,))
    position = models.CharField(max_length=300, verbose_name='Position')

    def __str__(self):
        return self.name + " " + self.surname

    class Meta:
        verbose_name = "Employee"
        verbose_name_plural = "Employee"
