from django.contrib import admin
from .models import Employee
# Register your models here.
from django.contrib.auth.models import Group
from allauth.account.models import EmailAddress

admin.site.register(Employee)
admin.site.unregister(Group)
admin.site.unregister(EmailAddress)