from django.shortcuts import render
from .models import Employee
from django.db.models import Q


def home(request):
    return render(request, "main/Home.html")


def user_main(request):
    return render(request, "main/UserMain.html")


def search(request):
    if request.method == 'GET':
        data = Employee.objects.all()

    if request.method == 'POST':
        data = Employee.objects.all()
        search_val = request.POST["search"]
        return_data = data.filter(
                Q(name__icontains=search_val) |
                Q(surname__icontains=search_val) |
                 Q(email__icontains=search_val) |
                Q(position__icontains=search_val) 
                
                
        )
        data = return_data

    return render(request, "mainpage/mainPage.html", {'data': data})
