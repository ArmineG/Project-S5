from allauth.account.forms import SignupForm
from django.core.exceptions import ValidationError


class MyCustomSignupForm(SignupForm):
    "This field accepts mail of ufar only"

    def clean(self):
        cleaned_data = super().clean()
        print(cleaned_data)
        email = cleaned_data.get("email")
        if email[len(email) - 8:] != "@ufar.am":
            self.add_error('email', "email doesn't belong to ufar")
        return cleaned_data

