////Empty fields Validation
function Validate() {
if(document.getElementById("name").value == ""  ) {
  var typ = document.getElementById("first");
  typ.style.border = "0.4px solid red"
  typ.addEventListener("focus", myFocusFunction, true);
    return false;
}
  if(document.getElementById("lname").value == ""  ) {
    var typ = document.getElementById("last");
    typ.style.border = "0.4px solid red"
    typ.addEventListener("focus", myFocusFunction, true);
      return false;
  }
  if(document.getElementById("gender").value == ""  ) {
    var typ = document.getElementById("genders");
    typ.style.border = "0.4px solid red"
    typ.addEventListener("focus", myFocusFunction, true);
      return false;
  }
  if(document.getElementById("pic").value == ""  ) {
    var typ = document.getElementById("file");
    typ.style.border = "0.4px solid red"
    typ.addEventListener("focus", myFocusFunction, true);
      return false;
  }
  if(document.getElementById("password").value == ""  ) {
    var typ = document.getElementById("pass");
    typ.style.border = "0.4px solid red"
    typ.addEventListener("focus", myFocusFunction, true);
      return false;
  }
    return true;

    
      function myFocusFunction() {
        document.getElementById("first").style.border = "red";
        document.getElementById("last").style.border = "red";
        document.getElementById("genders").style.border = "red";
        document.getElementById("file").style.border = "red";
        document.getElementById("pass").style.border = "red";
        
    }
   }

   //Email Validation
   function ValidateEmail(inputText)
   {
  var typ = document.getElementById("mail");
   var mailformat = /(^[a-zA-Z0-9.%+-]+@(?!ufar.am)$)/;;
   if(inputText.value.match(mailformat))
   {
   return true;
   }
   else
   {
   typ.style.border = "0.4px solid red";
   typ.addEventListener("focus", myFocusFunction, true);
   return false;
   }
   function myFocusFunction() {
    document.getElementById("mail").style.border = "red";}
   }
   ////Good Password Validation

   