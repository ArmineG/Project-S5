let state = false;
function toggle(){
    if(state){
        document.getElementById("psw").setAttribute("type","password");
        document.getElementById("eye").setAttribute("class", "fa fa-eye fa-lg")
        state = false;
    }
    else{
        document.getElementById("psw").setAttribute("type","text");
        document.getElementById("eye").setAttribute("class", "fa fa-eye-slash fa-lg")
        state= true;
    }
}

